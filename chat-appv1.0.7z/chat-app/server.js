const express = require('express');
const fs = require('fs');
const path = require('path');
const moment = require('moment');
const bodyParser = require('body-parser');

// 初始化 Express 应用
const app = express();
const port = 3000;

// 管理员密码
const adminPassword = 'hebei111222333';

// 使用 body-parser 来处理 POST 请求的 JSON 数据
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 日志文件夹路径
const logsDir = path.join(__dirname, 'logs');

// 如果日志文件夹不存在，则创建
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir);
}

// 获取当前日期并生成日志文件名
function getLogFileName() {
  const dateStr = moment().format('YYYY-MM-DD');
  let logFileNumber = 1;
  let logFileName;

  // 检查是否已经有该日期的日志文件，并按顺序递增编号
  while (true) {
    logFileName = path.join(logsDir, `chat-${dateStr}-${String(logFileNumber).padStart(3, '0')}.log`);
    if (!fs.existsSync(logFileName)) {
      break;
    }
    logFileNumber++;
  }
  return logFileName;
}

// 当前的日志文件
let currentLogFile = getLogFileName();

// 创建新的日志文件（每天自动更新日志文件）
function changeLogFile() {
  currentLogFile = getLogFileName(); // 获取新的日志文件名
  if (!fs.existsSync(currentLogFile)) {
    fs.writeFileSync(currentLogFile, '', 'utf8'); // 创建新的日志文件
  }
}

// 记录聊天的日志文件路径
function saveMessageToLog(message) {
  try {
    fs.appendFileSync(currentLogFile, message, 'utf8');
  } catch (error) {
    console.error('写入日志时出错:', error);
  }
}

// 发送聊天消息，并将消息保存到日志文件
app.post('/send-message', (req, res) => {
  const { username, message } = req.body;

  // 检查用户名和消息是否存在
  if (!username || !message) {
    return res.status(400).send({ error: '用户名和消息不能为空' });
  }

  const timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
  let logEntry = '';

  // 如果是 `hebeiadmin` 用户，处理特殊情况
  if (username === 'hebeiadmin') {
    logEntry = `${timestamp} 系统消息：${message}\n`;
  } else {
    logEntry = `${timestamp} ${username}: ${message}\n`;
  }

  // 将消息追加到日志文件
  saveMessageToLog(logEntry);
  return res.status(200).send({ success: true });
});

// 获取聊天记录
app.get('/chat-logs', (req, res) => {
  try {
    const logs = fs.readFileSync(currentLogFile, 'utf8').split('\n').filter(Boolean);
    const messages = logs.map(log => {
      const [timestamp, ...rest] = log.split(' ');
      const username = rest.slice(0, -1).join(' ');
      const message = rest.slice(-1).join(' ');
      return { timestamp, username, message };
    });
    res.json(messages);
  } catch (error) {
    res.status(500).send({ error: '获取聊天记录时出错' });
  }
});

// 更换日志文件（管理员功能）
app.post('/change-log', (req, res) => {
  changeLogFile(); // 切换到新的一天的日志文件
  return res.status(200).send({ success: true, newLogFile: currentLogFile });
});

// 删除指定聊天记录（管理员功能）
app.post('/delete-message', (req, res) => {
  const { timestamp, username } = req.body;

  if (!timestamp || !username) {
    return res.status(400).send({ error: '必须提供时间戳和用户名' });
  }

  try {
    // 读取当前日志文件
    const logs = fs.readFileSync(currentLogFile, 'utf8').split('\n').filter(Boolean);
    const filteredLogs = logs.filter(log => {
      const logParts = log.split(' ');
      const logTimestamp = logParts[0] + ' ' + logParts[1]; // 获取时间戳
      const logUsername = logParts.slice(2, -1).join(' '); // 获取用户名
      return !(logTimestamp === timestamp && logUsername === username); // 删除指定记录
    });

    // 将过滤后的日志保存回文件
    fs.writeFileSync(currentLogFile, filteredLogs.join('\n') + '\n', 'utf8');

    return res.status(200).send({ success: true });
  } catch (error) {
    return res.status(500).send({ error: '删除聊天记录时出错' });
  }
});

// 提供管理员登录页面（需要密码验证）
app.get('/admin-login', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin-login.html'));
});

// 提供管理员页面，需验证密码
app.post('/admin', (req, res) => {
  const { password } = req.body;
  if (password === adminPassword) {
    res.sendFile(path.join(__dirname, 'admin.html'));
  } else {
    res.status(403).send({ error: '密码错误，无法访问后台' });
  }
});

// 提供后台发送消息的功能
app.post('/admin-send-message', (req, res) => {
  const { message } = req.body;

  if (!message) {
    return res.status(400).send({ error: '消息不能为空' });
  }

  const timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
  const logEntry = `${timestamp} 系统消息：${message}\n`;

  saveMessageToLog(logEntry);

  return res.status(200).send({ success: true });
});

// 启动服务器
app.listen(port, () => {
  console.log(`服务器运行在 http://localhost:${port}`);
});
