document.getElementById('send-btn').addEventListener('click', sendMessage);

function sendMessage() {
  const username = document.getElementById('username').value.trim();
  const message = document.getElementById('message').value.trim();

  if (username === '' || message === '') {
    alert('请输入名称和消息');
    return;
  }

  fetch('/send-message', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ username, message })
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      document.getElementById('message').value = ''; // 清空输入框
      fetchChatLogs(); // 获取最新聊天记录
    }
  });
}

function fetchChatLogs() {
  fetch('/chat-logs')
    .then(response => response.json())
    .then(logs => {
      const chatBox = document.getElementById('chat-box');
      chatBox.innerHTML = ''; // 清空聊天框

      logs.forEach(log => {
        const logElement = document.createElement('div');
        logElement.textContent = `${log.timestamp} ${log.username}: ${log.message}`;
        chatBox.appendChild(logElement);
      });
    });
}

// 初始加载聊天记录
fetchChatLogs();
